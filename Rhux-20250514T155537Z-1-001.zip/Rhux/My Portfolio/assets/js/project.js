let currentSlide = 0;

function moveSlide(direction) {
  const slides = document.querySelectorAll('.slider-image');
  currentSlide = (currentSlide + direction + slides.length) % slides.length;
  document.querySelector('.slider-images').style.transform = `translateX(-${currentSlide * 100}%)`;
}

function openModal(id) {
  const modal = document.getElementById("modal" + capitalizeFirstLetter(id));
  if (modal) modal.style.display = "flex";
}

function closeModal(id) {
  const modal = document.getElementById("modal" + capitalizeFirstLetter(id));
  if (modal) modal.style.display = "none";
}

function capitalizeFirstLetter(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function scrollToTop() {
  window.scrollTo({ top: 0, behavior: "smooth" });
}
