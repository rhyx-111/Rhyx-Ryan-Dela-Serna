// Modal Functionality (for Projects)
function openModal(projectId) {
    document.getElementById(`modal${projectId}`).style.display = "block";
  }
  
  function closeModal(projectId) {
    document.getElementById(`modal${projectId}`).style.display = "none";
  }
  
  // Scroll to Top Button
  window.addEventListener("scroll", () => {
    const scrollBtn = document.getElementById("scrollTopBtn");
    scrollBtn.style.display = window.scrollY > 100 ? "block" : "none";
  });
  
  function scrollToTop() {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  
  // Image Slider Functionality
  let slideIndex = 0;
  
  function moveSlide(step) {
    const slides = document.querySelectorAll(".slider-image");
    slideIndex = (slideIndex + step + slides.length) % slides.length;
    const offset = -slideIndex * 100;
    document.querySelector(".slider-images").style.transform = `translateX(${offset}%)`;
  }
  